package com.auth.repository;

import com.auth.entity.Roles;

public interface RolesRepository extends BaseRepository<Roles, Integer>{

}
